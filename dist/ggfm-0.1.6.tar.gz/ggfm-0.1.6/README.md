GGFM is an open-source pipeline for graph foundation model based on PyTorch. We integrate SOTA graph foundation models.

It is under development, welcome join us!